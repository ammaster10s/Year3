﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Signup
{
    internal class info
    {
        public int ID { get; set; }
        public string fName { get; set; }
        public string LName { get; set; }
        public string Sex { get; set; }
        public string Bdate { get; set; }
        public string Email { get; set; }
        public string Occup { get; set; }
        public string Signup_User { get; set; }  
        public string Signup_Pass { get; set; }  

    }
}
